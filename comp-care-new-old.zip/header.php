<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CompCare System - IT Solutions Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- favicon -->
    <link rel="shortcut icon" href="img/logo/favicon.png" type="image/x-icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Saira:wght@500;600;700&display=swap"
        rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner"
        class="show position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->

    <!-- Topbar Start -->
    <!-- <div class="container-fluid bg-dark py-2 d-none d-md-flex">
        <div class="container">
            <div class="d-flex justify-content-between topbar">
                <div class="top-info">
                    <small class="me-3 text-white-50"><a href="#"><i
                                class="fas fa-map-marker-alt me-2 text-secondary"></i></a>23 Ranking Street, New
                        York</small>
                    <small class="me-3 text-white-50"><a href="#"><i
                                class="fas fa-envelope me-2 text-secondary"></i></a>Email@Example.com</small>
                </div>
                <div id="note" class="text-secondary d-none d-xl-flex"><small>Note : We help you to Grow your
                        Business</small></div>
                <div class="top-link">
                    <a href="" class="bg-light nav-fill btn btn-sm-square rounded-circle"><i
                            class="fab fa-facebook-f text-primary"></i></a>
                    <a href="" class="bg-light nav-fill btn btn-sm-square rounded-circle"><i
                            class="fab fa-twitter text-primary"></i></a>
                    <a href="" class="bg-light nav-fill btn btn-sm-square rounded-circle"><i
                            class="fab fa-instagram text-primary"></i></a>
                    <a href="" class="bg-light nav-fill btn btn-sm-square rounded-circle me-0"><i
                            class="fab fa-linkedin-in text-primary"></i></a>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Topbar End -->

    <!-- Navbar Start -->

    <div class="container-fluid nav_bar" id="nav__bar">
        <div class="container">
            <nav class="navbar navbar-dark navbar-expand-lg py-0">
                <a href="index.php
                " class="navbar-brand">
                    <img src="img/logo/logo-brand.png" alt="logo-image">
                </a>
                <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse"
                    data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <?php
                $current_page = basename($_SERVER['PHP_SELF']);
                ?>
                <div class="collapse navbar-collapse bg-transparent" id="navbarCollapse">
                    <div class="navbar-nav ms-auto mx-xl-auto p-0">
                        <a href="index.php" class="nav-item nav-link" <?php if ($current_page == './index.php')
                            echo 'class="active"'; ?>>Home</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" <?php if ($current_page == './index.php')
                                echo 'class="active"'; ?>>About Us</a>
                            <div class="dropdown-menu rounded">
                                <a href="#" class="dropdown-item">Established in 1994</a>
                                <div href="" class="dropdown-item dropdown-sub dropdown-toggle"
                                    data-bs-toggle="dropdown">
                                    Initial days
                                    <div class="dropdown-menu-sub rounded">
                                        <a href="#" class="dropdown-item">Electronic Security Solutions</a>
                                        <a href="#" class="dropdown-item">Infrastructure Works</a>
                                        <a href="#" class="dropdown-item">Computer Networks</a>
                                    </div>
                                </div>
                                <div href="" class="dropdown-item dropdown-sub dropdown-toggle"
                                    data-bs-toggle="dropdown">
                                    Expertise
                                    <div class="dropdown-menu-sub rounded">
                                        <a href="#" class="dropdown-item">Security Solutions</a>
                                        <a href="#" class="dropdown-item">IT – Hardware & Networks</a>
                                    </div>
                                </div>
                                <div href="" class="dropdown-item dropdown-sub dropdown-toggle"
                                    data-bs-toggle="dropdown">
                                    Team Strength
                                    <div class="dropdown-menu-sub rounded">
                                        <a href="#" class="dropdown-item">Total team of 110+ and scalable</a>
                                        <a href="#" class="dropdown-item">Multi-disciplinary and multi-skilled team</a>
                                    </div>
                                </div>

                                <a href="#" class="dropdown-item">Team Strength</a>
                            </div>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Business
                                Verticals</a>
                            <div class="dropdown-menu rounded">
                                <a href="#" class="dropdown-item">Electronic Security Solutions</a>
                                <a href="#" class="dropdown-item">Infrastructure Works</a>
                                <a href="#" class="dropdown-item">Computer Networks</a>
                            </div>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Major Projects</a>
                            <div class="dropdown-menu rounded">
                                <a href="#" class="dropdown-item">Electronic Security Solutions</a>
                                <a href="#" class="dropdown-item">Infrastructure Works</a>
                                <a href="#" class="dropdown-item">Computer Networks</a>
                                <a href="#" class="dropdown-item">ATMS Projects</a>
                                <a href="#" class="dropdown-item">Smart City Projects</a>
                            </div>
                        </div>

                        <a href="#" class="nav-item nav-link">Clients</a>
                        <a href="#" class="nav-item nav-link">Contact</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->