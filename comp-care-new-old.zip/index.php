<?php include 'header.php' ?>

<!-- Carousel Start -->
<div class="container-fluid px-0">
    <div id="carouselId" class="carousel slide" data-bs-ride="carousel">
        <ol class="carousel-indicators">
            <li data-bs-target="#carouselId" data-bs-slide-to="0" class="active" aria-current="true"
                aria-label="First slide"></li>
            <li data-bs-target="#carouselId" data-bs-slide-to="1" aria-label="Second slide"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
                <img src="img/carousel-1.jpg" class="img-fluid" alt="First slide">
                <div class="carousel-caption">
                    <div class="container carousel-content">
                        <h6 class="text-secondary h4 animated fadeInUp">Best IT Solutions</h6>
                        <h1 class="text-white display-1 mb-4 animated fadeInRight">An Innovative IT Solutions Agency
                        </h1>
                        <p class="mb-4 text-white fs-5 animated fadeInDown">Cutting-edge technology, tailored solutions,
                            seamless integration, and expert support for optimal IT efficiency and performance.
                        </p>
                        <a href="" class="me-2"><button type="button"
                                class="px-4 py-sm-3 px-sm-5 btn btn-primary rounded-pill carousel-content-btn1 animated fadeInLeft">Read
                                More</button></a>
                        <a href="" class="ms-2"><button type="button"
                                class="px-4 py-sm-3 px-sm-5 btn btn-primary rounded-pill carousel-content-btn2 animated fadeInRight">Contact
                                Us</button></a>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/carousel-2.jpg" class="img-fluid" alt="Second slide">
                <div class="carousel-caption">
                    <div class="container carousel-content">
                        <h6 class="text-secondary h4 animated fadeInUp">Best IT Solutions</h6>
                        <h1 class="text-white display-1 mb-4 animated fadeInLeft">Quality Digital Services You Really
                            Need!</h1>
                        <p class="mb-4 text-white fs-5 animated fadeInDown">Innovative IT solutions for peak efficiency,
                            seamless integration, and unparalleled performance with expert support and customization.
                        </p>
                        <a href="" class="me-2"><button type="button"
                                class="px-4 py-sm-3 px-sm-5 btn btn-primary rounded-pill carousel-content-btn1 animated fadeInLeft">Read
                                More</button></a>
                        <a href="" class="ms-2"><button type="button"
                                class="px-4 py-sm-3 px-sm-5 btn btn-primary rounded-pill carousel-content-btn2 animated fadeInRight">Contact
                                Us</button></a>
                    </div>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselId" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselId" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div>
<!-- Carousel End -->


<!-- Fact Start -->
<div class="container-fluid bg-secondary py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 wow fadeIn" data-wow-delay=".1s">
                <div class="d-flex counter">
                    <h1 class="me-3 text-dark counter-value">24</h1>
                    <h1 style="margin-left:-20px; margin-right:20px">+</h1>
                    <h5 class="text-white mt-1">Years of Experience</h5>
                </div>
            </div>
            <div class="col-lg-3 wow fadeIn" data-wow-delay=".3s">
                <div class="d-flex counter">
                    <!-- <h1 class="me-3 text-dark counter-value">25</h1> -->
                    <h5 class="text-white mt-1">Highly Trained & Certified Resources</h5>
                </div>
            </div>
            <div class="col-lg-3 wow fadeIn" data-wow-delay=".5s">
                <div class="d-flex counter">
                    <h1 class="me-3 text-dark counter-value">300</h1>
                    <h1 style="margin-left:-20px; margin-right:20px">+</h1>
                    <h5 class="text-white mt-1">Customers Served</h5>
                </div>
            </div>
            <div class="col-lg-3 wow fadeIn" data-wow-delay=".7s">
                <div class="d-flex counter">
                    <!-- <h1 class="me-3 text-dark counter-value">5</h1> -->
                    <h5 class="text-white mt-1">Best Technical Support & Awarded Product</h5>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Fact End -->


<!-- About Start -->
<div class="container-fluid my-4 my-md-5" id="about">
    <div class="container pt-5">
        <div class="row g-5">
            <div class="col-lg-5 col-md-6 col-sm-12 wow fadeIn" data-wow-delay=".3s">
                <div class="h-100 position-relative">
                    <img src="img/about-1.jpg" class="img-fluid w-75 rounded" alt="" style="margin-bottom: 25%;">
                    <div class="position-absolute w-75" style="top: 25%; left: 25%;">
                        <img src="img/about-2.jpg" class="img-fluid w-100 rounded" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-md-6 col-sm-12 wow fadeIn" data-wow-delay=".5s">
                <h5 class="text-primary">About Us</h5>
                <h1 class="mb-4">About CompCare System And It's Innovative IT Solutions</h1>
                <p>Since 1999 our company offers top notch IT Services for companies all over the world.</p>
                <p class="mb-4">

                    It is a long established fact that a reader will be distracted by the readable content of a page
                    when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal
                    distribution of letters, as opposed to using 'Content here, content here', making it look like
                    readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their
                    default model text, and a search for 'lorem ipsum' will uncover many web sites still in their
                    infancy.</p>
                <a href="" class="btn btn-secondary rounded-pill px-5 py-3 text-white">More Details</a>
            </div>
        </div>
    </div>
</div>
<!-- About End -->


<!-- Services Start -->
<!-- <div class="container-fluid services py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" data-wow-delay=".3s" style="max-width: 600px;">
            <h5 class="text-primary">Our Services</h5>
            <h1>Services Built Specifically For Your Business</h1>
        </div>
        <div class="row g-5 services-inner">
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".3s">
                <div class="services-item bg-light">
                    <div class="p-4 text-center services-content">
                        <div class="services-content-icon">
                            <i class="fa fa-code fa-7x mb-4"></i>
                            <h4 class="mb-3">Business Application Services</h4>
                            <p class="mb-4">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum.
                                Aliquam dolor eget urna ultricies tincidunt.</p>
                            <a href="" class="btn btn-secondary text-white px-5 py-3 rounded-pill">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".5s">
                <div class="services-item bg-light">
                    <div class="p-4 text-center services-content">
                        <div class="services-content-icon">
                            <i class="fa fa-file-code fa-7x mb-4"></i>
                            <h4 class="mb-3">Infrastructure Services</h4>
                            <p class="mb-4">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum.
                                Aliquam dolor eget urna ultricies tincidunt.</p>
                            <a href="" class="btn btn-secondary text-white px-5 py-3 rounded-pill">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".7s">
                <div class="services-item bg-light">
                    <div class="p-4 text-center services-content">
                        <div class="services-content-icon">
                            <i class="fa fa-external-link-alt fa-7x mb-4"></i>
                            <h4 class="mb-3">Manpower Services</h4>
                            <p class="mb-4">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum.
                                Aliquam dolor eget urna ultricies tincidunt.</p>
                            <a href="" class="btn btn-secondary text-white px-5 py-3 rounded-pill">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".3s">
                <div class="services-item bg-light">
                    <div class="p-4 text-center services-content">
                        <div class="services-content-icon">
                            <i class="fas fa-user-secret fa-7x mb-4"></i>
                            <h4 class="mb-3">Training Services</h4>
                            <p class="mb-4">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum.
                                Aliquam dolor eget urna ultricies tincidunt.</p>
                            <a href="" class="btn btn-secondary text-white px-5 py-3 rounded-pill">Read More</a>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".5s">
                <div class="services-item bg-light">
                    <div class="p-4 text-center services-content">
                        <div class="services-content-icon">
                            <i class="fa fa-envelope-open fa-7x mb-4"></i>
                            <h4 class="mb-3">Digital Marketing</h4>
                            <p class="mb-4">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum.
                                Aliquam dolor eget urna ultricies tincidunt.</p>
                            <a href="" class="btn btn-secondary text-white px-5 py-3 rounded-pill">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".7s">
                <div class="services-item bg-light">
                    <div class="p-4 text-center services-content">
                        <div class="services-content-icon">
                            <i class="fas fa-laptop fa-7x mb-4"></i>
                            <h4 class="mb-3">Programming</h4>
                            <p class="mb-4">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum.
                                Aliquam dolor eget urna ultricies tincidunt.</p>
                            <a href="" class="btn btn-secondary text-white px-5 py-3 rounded-pill">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->

<section class="product-and service" style="background-color: #EEF2F0; padding-top: 40px;     padding-bottom: 40px;">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="title-text">
                    <h2 style="font-size: 45px; font-weight: 600;">Products &<br> Services We<br>
                        Offering</h2>
                </div>
            </div>
            <div class="col-md-6">
                <div class="arrow-image">
                    <img src="img/Vector 111.png" width="100%">
                </div>
                <div class="para-text">
                    <div class="text">
                        <p style="font-size: 14px;">The point of using Lorem Ipsum is that it has a more-or-less normal
                            distribution of letters, as opposed to using 'Content here, content here', making it look
                            like rea model text, and a search for 'lorem ipsum' will uncover many web sites still in
                            their infancy.</p>
                    </div>

                </div>
            </div>
            <div class="col-md-2">
                <div class="abc" style=" text-align: end;">
                    <!-- <span class="about-arrow" style="position: absolute;
                        right: 25px"><img src="img/arrow-top.png" style="width: 12px;"></span> -->
                    <span style="color: #ED5B5A; font-size: 14px;">All Services <img src="img/arrow-top.png"
                            style="width: 12px;"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-4">
            <div class="col-md-6 mb-4">
                <div class="card-details custom-border"
                    style="padding: 68px 20px; border: 1px solid lightgrey; border-radius: 5px; background-color: #ED5B5A; color: #ffffff; box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;">
                    <div class="card-box">
                        <h2 style="font-size: 17px; padding: 10px;">IT Infra Service
                        </h2>
                    </div>
                    <div class="order-list" style="display: flex;justify-content: space-around;">
                        <div class="xxx">
                            <li>Server Administration</li>
                            <li>Scalability and Flexibility</li>
                        </div>
                        <div class="xxx">
                            <li>Security and Compliance</li>
                            <li>Storage Solutions</li>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-6 mb-4">
                <div class="card-details card__detail-3 custom-border"
                    style="padding: 68px 20px; border: 1px solid lightgrey; border-radius: 5px;">
                    <div class="card-box">
                        <h2 style="font-size: 17px; padding: 10px;">iOT
                        </h2>
                    </div>
                    <div class="order-list" style="display: flex;justify-content: space-around;">
                        <div class="xxx">
                            <li>Connectivity</li>
                            <li>Data Collection and Analysis</li>
                        </div>
                        <div class="xxx">
                            <li>Automation and Control</li>
                            <li>Security Concerns</li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-4">
            <div class="col-md-6 mb-4">
                <div class="card-details custom-border"
                    style="padding: 68px 20px; border: 1px solid lightgrey; border-radius: 5px;">
                    <div class="card-box">
                        <h2 style="font-size: 17px; padding: 10px;">Business Application Services</h2>
                    </div>
                    <div class="order-list" style="display: flex;justify-content: space-around;">
                        <div class="xxx">
                            <li>Digital</li>
                            <li>BI & Analytics</li>
                        </div>
                        <div class="xxx">
                            <li>Robotics Process Automation</li>
                            <li>Enterprise Resource Planning (ERP)</li>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-6 mb-4">
                <div class="card-details card__detail-1"
                    style="padding: 68px 20px; border: 1px solid lightgrey; border-radius: 5px; background-color: #ED5B5A; color: #ffffff; box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;">
                    <div class="card-box">
                        <h2 style="font-size: 17px; padding: 10px; color: #ffffff;">ATMs automatic traffic management
                        </h2>
                    </div>
                    <div class="order-list" style="display: flex;justify-content: space-around;">
                        <div class="xxx">
                            <li>Traffic Flow Analysis</li>
                            <li>Technology Integration</li>
                        </div>
                        <div class="xxx">
                            <li>Security Measures</li>
                            <li>Real-time Monitoring</li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-4">
            <div class="col-md-6 mb-4">
                <div class="card-details custom-border"
                    style="padding: 68px 20px; border: 1px solid lightgrey; border-radius: 5px; background-color: #ED5B5A; color: #ffffff; box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;">
                    <div class="card-box">
                        <h2 style="font-size: 17px; padding: 10px;">Manpower Services
                        </h2>
                    </div>
                    <div class="order-list" style="display: flex;justify-content: space-around;">
                        <div class="xxx">
                            <li>Sourcing</li>
                            <li>Compliance</li>
                        </div>
                        <div class="xxx">
                            <li>Staffing</li>
                            <li>Training</li>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-6 mb-4">
                <div class="card-details card__detail-2 custom-border"
                    style="padding: 68px 20px; border: 1px solid lightgrey; border-radius: 5px;">
                    <div class="card-box">
                        <h2 style="font-size: 17px; padding: 10px;">Training Services
                        </h2>
                    </div>
                    <div class="order-list" style="display: flex;justify-content: space-around;">
                        <div class="xxx">
                            <li>Individual Solutions</li>
                            <li>Progress Monitoring</li>
                        </div>
                        <div class="xxx">
                            <li>Corporate Solutions</li>
                            <li>Skill Assessment</li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Services End -->


<!-- Project Start -->
<div class="container-fluid project py-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" data-wow-delay=".3s" style="max-width: 600px;">
            <h5 class="text-primary">Our Project</h5>
            <h1>Our Recently Completed Projects</h1>
        </div>
        <div class="row g-5 justify-content-center">
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".3s">
                <div class="project-item">
                    <div class="project-img">
                        <img src="img/project/img-01.png" class="img-fluid w-100 rounded" alt="">
                        <div class="project-content">
                            <a href="#" class="text-center">
                                <h4 class="text-dark">Mumbai City Surveillance – Home Department </h4>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".5s">
                <div class="project-item">
                    <div class="project-img">
                        <img src="img/project/img-02.png" class="img-fluid w-100 rounded" alt="">
                        <div class="project-content">
                            <a href="#" class="text-center">
                                <h4 class="text-dark">Enterprise Access Control System</h4>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".7s">
                <div class="project-item">
                    <div class="project-img">
                        <img src="img/project/img-03.png" class="img-fluid w-100 rounded" alt="">
                        <div class="project-content">
                            <a href="#" class="text-center">
                                <h4 class="text-dark">Main Command & Control Centre under RRVPNL</h4>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Project End -->


<!-- Blog Start -->
<div class="container-fluid blog py-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" data-wow-delay=".3s" style="max-width: 600px;">
            <h5 class="text-primary">Our Blog</h5>
            <h1>Trending IT Solution Article & Tips</h1>
        </div>
        <div class="row g-5 justify-content-center">
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".3s">
                <div class="blog-item position-relative bg-light rounded">
                    <img src="img/blog-1.jpg" class="img-fluid w-100 rounded-top" alt="">
                    <!-- <span class="position-absolute px-4 py-3 bg-primary text-white rounded"
                        style="top: -28px; right: 20px;">Web Design</span> -->
                    <div class="blog-content text-center position-relative px-3" style="margin-top: -25px;">
                        <img src="img/admin.jpg" class="img-fluid rounded-circle border border-4 border-white mb-3"
                            alt="">
                        <h5 class="">By Daniel Martin</h5>
                        <span class="text-secondary">24 March 2023</span>
                        <p class="">Regional Manager & Limited
                            Time Management.</p>
                    </div>

                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".5s">
                <div class="blog-item position-relative bg-light rounded">
                    <img src="img/blog-2.jpg" class="img-fluid w-100 rounded-top" alt="">
                    <!-- <span class="position-absolute px-4 py-3 bg-primary text-white rounded"
                        style="top: -28px; right: 20px;">Development</span> -->

                    <div class="blog-content text-center position-relative px-3" style="margin-top: -25px;">
                        <img src="img/admin.jpg" class="img-fluid rounded-circle border border-4 border-white mb-3"
                            alt="">
                        <h5 class="">By Daniel Martin</h5>
                        <span class="text-secondary">23 April 2023</span>
                        <p class="">How Granite Countertops Are
                            Made: A Step-by-Step Process</p>
                    </div>

                </div>
            </div>
            <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".7s">
                <div class="blog-item position-relative bg-light rounded">
                    <img src="img/blog-3.jpg" class="img-fluid w-100 rounded-top" alt="">
                    <!-- <span class="position-absolute px-4 py-3 bg-primary text-white rounded"
                        style="top: -28px; right: 20px;">Mobile App</span> -->

                    <div class="blog-content text-center position-relative px-3" style="margin-top: -25px;">
                        <img src="img/admin.jpg" class="img-fluid rounded-circle border border-4 border-white mb-3"
                            alt="">
                        <h5 class="">By Daniel Martin</h5>
                        <span class="text-secondary">30 jan 2023</span>
                        <p class="">Will Granite Countertops
                            Always Be in Style?</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Blog End -->


<!-- Team Start -->
<div class="container-fluid py-5 team">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" data-wow-delay=".3s" style="max-width: 700px;">
            <h5 class="text-primary">Our Clients</h5>
            <h1>Partnering for Your Success Together.</h1>
        </div>
        <div class="owl-carousel team-carousel wow fadeIn" data-wow-delay=".5s">
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="img/clients/bharat.png" class="img-fluid w-100 rounded-circle" alt="">
                        </div>
                        <!-- <div class="team-name text-center py-3">
                            <h4 class="">Full Name</h4>
                            <p class="m-0">Designation</p>
                        </div> -->

                    </div>
                </div>
            </div>
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="img/clients/CMS.png" class="img-fluid w-100 rounded-circle" alt="">
                        </div>
                        <!-- <div class="team-name text-center py-3">
                            <h4 class="">Full Name</h4>
                            <p class="m-0">Designation</p>
                        </div> -->

                    </div>
                </div>
            </div>
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="img/clients/credable-logo.png" class="img-fluid w-100 rounded-circle" alt="">
                        </div>
                        <!-- <div class="team-name text-center py-3">
                            <h4 class="">Full Name</h4>
                            <p class="m-0">Designation</p>
                        </div> -->

                    </div>
                </div>
            </div>
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="img/clients/icic-logo.png" class="img-fluid w-100 rounded-circle" alt="">
                        </div>
                        <!-- <div class="team-name text-center py-3">
                            <h4 class="">Full Name</h4>
                            <p class="m-0">Designation</p>
                        </div> -->

                    </div>
                </div>
            </div>
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="img/clients/indudind.png" class="img-fluid w-100 rounded-circle" alt="">
                        </div>
                        <!-- <div class="team-name text-center py-3">
                            <h4 class="">Full Name</h4>
                            <p class="m-0">Designation</p>
                        </div> -->

                    </div>
                </div>
            </div>
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="img/clients/l&t-logo.png" class="img-fluid w-100 rounded-circle" alt="">
                        </div>
                        <!-- <div class="team-name text-center py-3">
                            <h4 class="">Full Name</h4>
                            <p class="m-0">Designation</p>
                        </div> -->

                    </div>
                </div>
            </div>
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="img/clients/ongc-logo.png" class="img-fluid w-100 rounded-circle" alt="">
                        </div>
                        <!-- <div class="team-name text-center py-3">
                            <h4 class="">Full Name</h4>
                            <p class="m-0">Designation</p>
                        </div> -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Team End -->

<!-- Testimonial Start -->
<!-- <div class="container-fluid testimonial py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" data-wow-delay=".3s" style="max-width: 600px;">
            <h5 class="text-primary">Our Testimonial</h5>
            <h1>Our Client Saying!</h1>
        </div>
        <div class="owl-carousel testimonial-carousel wow fadeIn" data-wow-delay=".5s">
            <div class="testimonial-item border p-4">
                <div class="d-flex align-items-center">
                    <div class="">
                        <img src="img/testimonial-1.jpg" alt="">
                    </div>
                    <div class="ms-4">
                        <h4 class="text-secondary">Client Name</h4>
                        <p class="m-0 pb-3">Profession</p>
                        <div class="d-flex pe-5">
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                        </div>
                    </div>
                </div>
                <div class="border-top mt-4 pt-3">
                    <p class="mb-0">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum aliquam dolor
                        eget urna. Nam volutpat libero sit amet leo cursus, ac viverra eros morbi quis quam mi.</p>
                </div>
            </div>
            <div class="testimonial-item border p-4">
                <div class=" d-flex align-items-center">
                    <div class="">
                        <img src="img/testimonial-2.jpg" alt="">
                    </div>
                    <div class="ms-4">
                        <h4 class="text-secondary">Client Name</h4>
                        <p class="m-0 pb-3">Profession</p>
                        <div class="d-flex pe-5">
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                        </div>
                    </div>
                </div>
                <div class="border-top mt-4 pt-3">
                    <p class="mb-0">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum aliquam dolor
                        eget urna. Nam volutpat libero sit amet leo cursus, ac viverra eros morbi quis quam mi.</p>
                </div>
            </div>
            <div class="testimonial-item border p-4">
                <div class=" d-flex align-items-center">
                    <div class="">
                        <img src="img/testimonial-3.jpg" alt="">
                    </div>
                    <div class="ms-4">
                        <h4 class="text-secondary">Client Name</h4>
                        <p class="m-0 pb-3">Profession</p>
                        <div class="d-flex pe-5">
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                        </div>
                    </div>
                </div>
                <div class="border-top mt-4 pt-3">
                    <p class="mb-0">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum aliquam dolor
                        eget urna. Nam volutpat libero sit amet leo cursus, ac viverra eros morbi quis quam mi.</p>
                </div>
            </div>
            <div class="testimonial-item border p-4">
                <div class=" d-flex align-items-center">
                    <div class="">
                        <img src="img/testimonial-4.jpg" alt="">
                    </div>
                    <div class="ms-4">
                        <h4 class="text-secondary">Client Name</h4>
                        <p class="m-0 pb-3">Profession</p>
                        <div class="d-flex pe-5">
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                            <i class="fas fa-star me-1 text-primary"></i>
                        </div>
                    </div>
                </div>
                <div class="border-top mt-4 pt-3">
                    <p class="mb-0">Lorem ipsum dolor sit amet elit. Sed efficitur quis purus ut interdum aliquam dolor
                        eget urna. Nam volutpat libero sit amet leo cursus, ac viverra eros morbi quis quam mi.</p>
                </div>
            </div>
        </div>
    </div>
</div> -->

<!-- Testimonial End -->


<!-- Contact Start -->
<div class="container-fluid py-5">
    <div class="container" id="contact_detail">
        <div class="text-center mx-auto pb-5 wow fadeIn" data-wow-delay=".3s" style="max-width: 600px;">
            <h5 class="text-primary">Get In Touch</h5>
            <h1 class="mb-3">Contact for any query</h1>

        </div>
        <div class="contact-detail position-relative p-5">
            <div class="row g-5 mb-5 justify-content-center">
                <div class="col-xl-4 col-lg-6 wow fadeIn" data-wow-delay=".3s">
                    <div class="d-flex bg-light p-3 rounded">
                        <div class="flex-shrink-0 btn-square bg-secondary rounded-circle"
                            style="width: 64px; height: 64px;">
                            <i class="fas fa-map-marker-alt text-white"></i>
                        </div>
                        <div class="ms-3">
                            <h4 class="text-primary">Address</h4>
                            <a href="#" target="_blank" class="h5">New Delhi, India</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 wow fadeIn" data-wow-delay=".5s">
                    <div class="d-flex bg-light p-3 rounded">
                        <div class="flex-shrink-0 btn-square bg-secondary rounded-circle"
                            style="width: 64px; height: 64px;">
                            <i class="fa fa-phone-alt text-white"></i>
                        </div>
                        <div class="ms-3">
                            <h4 class="text-primary">Call Us</h4>
                            <a class="h5" href="#" target="_blank">+012 3456 7890</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 wow fadeIn" data-wow-delay=".7s">
                    <div class="d-flex bg-light p-3 rounded">
                        <div class="flex-shrink-0 btn-square bg-secondary rounded-circle"
                            style="width: 64px; height: 64px;">
                            <i class="fa fa-envelope text-white"></i>
                        </div>
                        <div class="ms-3">
                            <h4 class="text-primary">Email Us</h4>
                            <a class="h5" href="#" target="_blank">info@example.com</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-5">
                <div class="col-lg-6 wow fadeIn" data-wow-delay=".3s">
                    <div class="p-5 h-100 rounded contact-map">
                        <iframe class="rounded w-100 h-100"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d224345.8979724198!2d77.0441739758312!3d28.52755440805166!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x52c2b7494e204dce!2sNew%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1704952065462!5m2!1sen!2sin"
                            style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay=".5s">
                    <div class="p-5 rounded contact-form">
                        <div class="mb-4">
                            <input type="text" class="form-control border-0 py-3" placeholder="Your Name">
                        </div>
                        <div class="mb-4">
                            <input type="email" class="form-control border-0 py-3" placeholder="Your Email">
                        </div>
                        <div class="mb-4">
                            <input type="text" class="form-control border-0 py-3" placeholder="Project">
                        </div>
                        <div class="mb-4">
                            <textarea class="w-100 form-control border-0 py-3" rows="4" cols="10"
                                placeholder="Message"></textarea>
                        </div>
                        <div class="text-start">
                            <button class="btn white-btn py-3 px-5" type="button">Send Message</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact End -->

<?php include 'footer.php' ?>